package com.supercoding.project_sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectSampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectSampleApplication.class, args);
    }

}
