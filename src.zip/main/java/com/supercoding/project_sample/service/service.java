package com.supercoding.project_sample.service;

public class service {
}
