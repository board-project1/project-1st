package com.supercoding.project_sample.repository;

public class repository {
}
