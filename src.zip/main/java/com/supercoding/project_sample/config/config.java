package com.supercoding.project_sample.config;

public class config {
}
