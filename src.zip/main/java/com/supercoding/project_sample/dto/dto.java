package com.supercoding.project_sample.dto;

public class dto {
}
