package com.supercoding.project_sample.domain;

public class domain {
}
